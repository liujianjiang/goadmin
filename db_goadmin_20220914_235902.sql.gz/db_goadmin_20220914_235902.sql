-- MySQL dump 10.13  Distrib 8.0.24, for Linux (x86_64)
--
-- Host: localhost    Database: goadmin
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `casbin_rule`
--

DROP TABLE IF EXISTS `casbin_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `casbin_rule` (
  `p_type` varchar(100) DEFAULT NULL,
  `v0` varchar(100) DEFAULT NULL,
  `v1` varchar(100) DEFAULT NULL,
  `v2` varchar(100) DEFAULT NULL,
  `v3` varchar(100) DEFAULT NULL,
  `v4` varchar(100) DEFAULT NULL,
  `v5` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casbin_rule`
--

LOCK TABLES `casbin_rule` WRITE;
/*!40000 ALTER TABLE `casbin_rule` DISABLE KEYS */;
INSERT INTO `casbin_rule` VALUES ('p','888','/base/login','POST','','',''),('p','888','/user/admin_register','POST','','',''),('p','888','/api/createApi','POST','','',''),('p','888','/api/getApiList','POST','','',''),('p','888','/api/getApiById','POST','','',''),('p','888','/api/deleteApi','POST','','',''),('p','888','/api/updateApi','POST','','',''),('p','888','/api/getAllApis','POST','','',''),('p','888','/api/deleteApisByIds','DELETE','','',''),('p','888','/authority/copyAuthority','POST','','',''),('p','888','/authority/updateAuthority','PUT','','',''),('p','888','/authority/createAuthority','POST','','',''),('p','888','/authority/deleteAuthority','POST','','',''),('p','888','/authority/getAuthorityList','POST','','',''),('p','888','/authority/setDataAuthority','POST','','',''),('p','888','/menu/getMenu','POST','','',''),('p','888','/menu/getMenuList','POST','','',''),('p','888','/menu/addBaseMenu','POST','','',''),('p','888','/menu/getBaseMenuTree','POST','','',''),('p','888','/menu/addMenuAuthority','POST','','',''),('p','888','/menu/getMenuAuthority','POST','','',''),('p','888','/menu/deleteBaseMenu','POST','','',''),('p','888','/menu/updateBaseMenu','POST','','',''),('p','888','/menu/getBaseMenuById','POST','','',''),('p','888','/user/getUserInfo','GET','','',''),('p','888','/user/setUserInfo','PUT','','',''),('p','888','/user/setSelfInfo','PUT','','',''),('p','888','/user/getUserList','POST','','',''),('p','888','/user/deleteUser','DELETE','','',''),('p','888','/user/changePassword','POST','','',''),('p','888','/user/setUserAuthority','POST','','',''),('p','888','/user/setUserAuthorities','POST','','',''),('p','888','/user/resetPassword','POST','','',''),('p','888','/fileUploadAndDownload/findFile','GET','','',''),('p','888','/fileUploadAndDownload/breakpointContinueFinish','POST','','',''),('p','888','/fileUploadAndDownload/breakpointContinue','POST','','',''),('p','888','/fileUploadAndDownload/removeChunk','POST','','',''),('p','888','/fileUploadAndDownload/upload','POST','','',''),('p','888','/fileUploadAndDownload/deleteFile','POST','','',''),('p','888','/fileUploadAndDownload/editFileName','POST','','',''),('p','888','/fileUploadAndDownload/getFileList','POST','','',''),('p','888','/casbin/updateCasbin','POST','','',''),('p','888','/casbin/getPolicyPathByAuthorityId','POST','','',''),('p','888','/jwt/jsonInBlacklist','POST','','',''),('p','888','/system/getSystemConfig','POST','','',''),('p','888','/system/setSystemConfig','POST','','',''),('p','888','/system/getServerInfo','POST','','',''),('p','888','/customer/customer','GET','','',''),('p','888','/customer/customer','PUT','','',''),('p','888','/customer/customer','POST','','',''),('p','888','/customer/customer','DELETE','','',''),('p','888','/customer/customerList','GET','','',''),('p','888','/autoCode/getDB','GET','','',''),('p','888','/autoCode/getMeta','POST','','',''),('p','888','/autoCode/preview','POST','','',''),('p','888','/autoCode/getTables','GET','','',''),('p','888','/autoCode/getColumn','GET','','',''),('p','888','/autoCode/rollback','POST','','',''),('p','888','/autoCode/createTemp','POST','','',''),('p','888','/autoCode/delSysHistory','POST','','',''),('p','888','/autoCode/getSysHistory','POST','','',''),('p','888','/autoCode/createPackage','POST','','',''),('p','888','/autoCode/getPackage','POST','','',''),('p','888','/autoCode/delPackage','POST','','',''),('p','888','/autoCode/createPlug','POST','','',''),('p','888','/sysDictionaryDetail/findSysDictionaryDetail','GET','','',''),('p','888','/sysDictionaryDetail/updateSysDictionaryDetail','PUT','','',''),('p','888','/sysDictionaryDetail/createSysDictionaryDetail','POST','','',''),('p','888','/sysDictionaryDetail/getSysDictionaryDetailList','GET','','',''),('p','888','/sysDictionaryDetail/deleteSysDictionaryDetail','DELETE','','',''),('p','888','/sysDictionary/findSysDictionary','GET','','',''),('p','888','/sysDictionary/updateSysDictionary','PUT','','',''),('p','888','/sysDictionary/getSysDictionaryList','GET','','',''),('p','888','/sysDictionary/createSysDictionary','POST','','',''),('p','888','/sysDictionary/deleteSysDictionary','DELETE','','',''),('p','888','/sysOperationRecord/findSysOperationRecord','GET','','',''),('p','888','/sysOperationRecord/updateSysOperationRecord','PUT','','',''),('p','888','/sysOperationRecord/createSysOperationRecord','POST','','',''),('p','888','/sysOperationRecord/getSysOperationRecordList','GET','','',''),('p','888','/sysOperationRecord/deleteSysOperationRecord','DELETE','','',''),('p','888','/sysOperationRecord/deleteSysOperationRecordByIds','DELETE','','',''),('p','888','/email/emailTest','POST','','',''),('p','888','/simpleUploader/upload','POST','','',''),('p','888','/simpleUploader/checkFileMd5','GET','','',''),('p','888','/simpleUploader/mergeFileMd5','GET','','',''),('p','888','/excel/importExcel','POST','','',''),('p','888','/excel/loadExcel','GET','','',''),('p','888','/excel/exportExcel','POST','','',''),('p','888','/excel/downloadTemplate','GET','','',''),('p','888','/authorityBtn/setAuthorityBtn','POST','','',''),('p','888','/authorityBtn/getAuthorityBtn','POST','','',''),('p','888','/authorityBtn/canRemoveAuthorityBtn','POST','','',''),('p','8881','/base/login','POST','','',''),('p','8881','/user/admin_register','POST','','',''),('p','8881','/api/createApi','POST','','',''),('p','8881','/api/getApiList','POST','','',''),('p','8881','/api/getApiById','POST','','',''),('p','8881','/api/deleteApi','POST','','',''),('p','8881','/api/updateApi','POST','','',''),('p','8881','/api/getAllApis','POST','','',''),('p','8881','/authority/createAuthority','POST','','',''),('p','8881','/authority/deleteAuthority','POST','','',''),('p','8881','/authority/getAuthorityList','POST','','',''),('p','8881','/authority/setDataAuthority','POST','','',''),('p','8881','/menu/getMenu','POST','','',''),('p','8881','/menu/getMenuList','POST','','',''),('p','8881','/menu/addBaseMenu','POST','','',''),('p','8881','/menu/getBaseMenuTree','POST','','',''),('p','8881','/menu/addMenuAuthority','POST','','',''),('p','8881','/menu/getMenuAuthority','POST','','',''),('p','8881','/menu/deleteBaseMenu','POST','','',''),('p','8881','/menu/updateBaseMenu','POST','','',''),('p','8881','/menu/getBaseMenuById','POST','','',''),('p','8881','/user/changePassword','POST','','',''),('p','8881','/user/getUserList','POST','','',''),('p','8881','/user/setUserAuthority','POST','','',''),('p','8881','/fileUploadAndDownload/upload','POST','','',''),('p','8881','/fileUploadAndDownload/getFileList','POST','','',''),('p','8881','/fileUploadAndDownload/deleteFile','POST','','',''),('p','8881','/fileUploadAndDownload/editFileName','POST','','',''),('p','8881','/casbin/updateCasbin','POST','','',''),('p','8881','/casbin/getPolicyPathByAuthorityId','POST','','',''),('p','8881','/jwt/jsonInBlacklist','POST','','',''),('p','8881','/system/getSystemConfig','POST','','',''),('p','8881','/system/setSystemConfig','POST','','',''),('p','8881','/customer/customer','POST','','',''),('p','8881','/customer/customer','PUT','','',''),('p','8881','/customer/customer','DELETE','','',''),('p','8881','/customer/customer','GET','','',''),('p','8881','/customer/customerList','GET','','',''),('p','8881','/user/getUserInfo','GET','','',''),('p','9528','/base/login','POST','','',''),('p','9528','/user/admin_register','POST','','',''),('p','9528','/api/createApi','POST','','',''),('p','9528','/api/getApiList','POST','','',''),('p','9528','/api/getApiById','POST','','',''),('p','9528','/api/deleteApi','POST','','',''),('p','9528','/api/updateApi','POST','','',''),('p','9528','/api/getAllApis','POST','','',''),('p','9528','/authority/createAuthority','POST','','',''),('p','9528','/authority/deleteAuthority','POST','','',''),('p','9528','/authority/getAuthorityList','POST','','',''),('p','9528','/authority/setDataAuthority','POST','','',''),('p','9528','/menu/getMenu','POST','','',''),('p','9528','/menu/getMenuList','POST','','',''),('p','9528','/menu/addBaseMenu','POST','','',''),('p','9528','/menu/getBaseMenuTree','POST','','',''),('p','9528','/menu/addMenuAuthority','POST','','',''),('p','9528','/menu/getMenuAuthority','POST','','',''),('p','9528','/menu/deleteBaseMenu','POST','','',''),('p','9528','/menu/updateBaseMenu','POST','','',''),('p','9528','/menu/getBaseMenuById','POST','','',''),('p','9528','/user/changePassword','POST','','',''),('p','9528','/user/getUserList','POST','','',''),('p','9528','/user/setUserAuthority','POST','','',''),('p','9528','/fileUploadAndDownload/upload','POST','','',''),('p','9528','/fileUploadAndDownload/getFileList','POST','','',''),('p','9528','/fileUploadAndDownload/deleteFile','POST','','',''),('p','9528','/fileUploadAndDownload/editFileName','POST','','',''),('p','9528','/casbin/updateCasbin','POST','','',''),('p','9528','/casbin/getPolicyPathByAuthorityId','POST','','',''),('p','9528','/jwt/jsonInBlacklist','POST','','',''),('p','9528','/system/getSystemConfig','POST','','',''),('p','9528','/system/setSystemConfig','POST','','',''),('p','9528','/customer/customer','PUT','','',''),('p','9528','/customer/customer','GET','','',''),('p','9528','/customer/customer','POST','','',''),('p','9528','/customer/customer','DELETE','','',''),('p','9528','/customer/customerList','GET','','',''),('p','9528','/autoCode/createTemp','POST','','',''),('p','9528','/user/getUserInfo','GET','','','');
/*!40000 ALTER TABLE `casbin_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exa_customers`
--

DROP TABLE IF EXISTS `exa_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exa_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `customer_name` varchar(191) DEFAULT NULL COMMENT '客户名',
  `customer_phone_data` varchar(191) DEFAULT NULL COMMENT '客户手机号',
  `sys_user_id` bigint unsigned DEFAULT NULL COMMENT '管理ID',
  `sys_user_authority_id` bigint unsigned DEFAULT NULL COMMENT '管理角色ID',
  PRIMARY KEY (`id`),
  KEY `idx_exa_customers_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exa_customers`
--

LOCK TABLES `exa_customers` WRITE;
/*!40000 ALTER TABLE `exa_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `exa_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exa_file_chunks`
--

DROP TABLE IF EXISTS `exa_file_chunks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exa_file_chunks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `exa_file_id` bigint unsigned DEFAULT NULL,
  `file_chunk_number` bigint DEFAULT NULL,
  `file_chunk_path` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_exa_file_chunks_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exa_file_chunks`
--

LOCK TABLES `exa_file_chunks` WRITE;
/*!40000 ALTER TABLE `exa_file_chunks` DISABLE KEYS */;
/*!40000 ALTER TABLE `exa_file_chunks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exa_file_upload_and_downloads`
--

DROP TABLE IF EXISTS `exa_file_upload_and_downloads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exa_file_upload_and_downloads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL COMMENT '文件名',
  `url` varchar(191) DEFAULT NULL COMMENT '文件地址',
  `tag` varchar(191) DEFAULT NULL COMMENT '文件标签',
  `key` varchar(191) DEFAULT NULL COMMENT '编号',
  PRIMARY KEY (`id`),
  KEY `idx_exa_file_upload_and_downloads_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exa_file_upload_and_downloads`
--

LOCK TABLES `exa_file_upload_and_downloads` WRITE;
/*!40000 ALTER TABLE `exa_file_upload_and_downloads` DISABLE KEYS */;
INSERT INTO `exa_file_upload_and_downloads` VALUES (1,'2022-07-08 06:38:24.970','2022-07-08 06:38:24.970',NULL,'10.png','https://qmplusimg.henrongyi.top/gvalogo.png','png','158787308910.png'),(2,'2022-07-08 06:38:24.970','2022-07-08 06:38:24.970',NULL,'logo.png','https://qmplusimg.henrongyi.top/1576554439myAvatar.png','png','1587973709logo.png');
/*!40000 ALTER TABLE `exa_file_upload_and_downloads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exa_files`
--

DROP TABLE IF EXISTS `exa_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exa_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_md5` varchar(191) DEFAULT NULL,
  `file_path` varchar(191) DEFAULT NULL,
  `chunk_total` bigint DEFAULT NULL,
  `is_finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_exa_files_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exa_files`
--

LOCK TABLES `exa_files` WRITE;
/*!40000 ALTER TABLE `exa_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `exa_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jwt_blacklists`
--

DROP TABLE IF EXISTS `jwt_blacklists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jwt_blacklists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `jwt` text COMMENT 'jwt',
  PRIMARY KEY (`id`),
  KEY `idx_jwt_blacklists_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jwt_blacklists`
--

LOCK TABLES `jwt_blacklists` WRITE;
/*!40000 ALTER TABLE `jwt_blacklists` DISABLE KEYS */;
/*!40000 ALTER TABLE `jwt_blacklists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_apis`
--

DROP TABLE IF EXISTS `sys_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_apis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `path` varchar(191) DEFAULT NULL COMMENT 'api路径',
  `description` varchar(191) DEFAULT NULL COMMENT 'api中文描述',
  `api_group` varchar(191) DEFAULT NULL COMMENT 'api组',
  `method` varchar(191) DEFAULT 'POST' COMMENT '方法',
  PRIMARY KEY (`id`),
  KEY `idx_sys_apis_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_apis`
--

LOCK TABLES `sys_apis` WRITE;
/*!40000 ALTER TABLE `sys_apis` DISABLE KEYS */;
INSERT INTO `sys_apis` VALUES (1,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/base/login','用户登录(必选)','base','POST'),(2,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/jwt/jsonInBlacklist','jwt加入黑名单(退出，必选)','jwt','POST'),(3,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/deleteUser','删除用户','系统用户','DELETE'),(4,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/admin_register','用户注册','系统用户','POST'),(5,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/getUserList','获取用户列表','系统用户','POST'),(6,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/setUserInfo','设置用户信息','系统用户','PUT'),(7,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/setSelfInfo','设置自身信息(必选)','系统用户','PUT'),(8,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/getUserInfo','获取自身信息(必选)','系统用户','GET'),(9,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/setUserAuthorities','设置权限组','系统用户','POST'),(10,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/changePassword','修改密码（建议选择)','系统用户','POST'),(11,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/setUserAuthority','修改用户角色(必选)','系统用户','POST'),(12,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/user/resetPassword','重置用户密码','系统用户','POST'),(13,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/createApi','创建api','api','POST'),(14,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/deleteApi','删除Api','api','POST'),(15,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/updateApi','更新Api','api','POST'),(16,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/getApiList','获取api列表','api','POST'),(17,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/getAllApis','获取所有api','api','POST'),(18,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/getApiById','获取api详细信息','api','POST'),(19,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/api/deleteApisByIds','批量删除api','api','DELETE'),(20,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/copyAuthority','拷贝角色','角色','POST'),(21,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/createAuthority','创建角色','角色','POST'),(22,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/deleteAuthority','删除角色','角色','POST'),(23,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/updateAuthority','更新角色信息','角色','PUT'),(24,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/getAuthorityList','获取角色列表','角色','POST'),(25,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authority/setDataAuthority','设置角色资源权限','角色','POST'),(26,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/casbin/updateCasbin','更改角色api权限','casbin','POST'),(27,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/casbin/getPolicyPathByAuthorityId','获取权限列表','casbin','POST'),(28,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/addBaseMenu','新增菜单','菜单','POST'),(29,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/getMenu','获取菜单树(必选)','菜单','POST'),(30,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/deleteBaseMenu','删除菜单','菜单','POST'),(31,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/updateBaseMenu','更新菜单','菜单','POST'),(32,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/getBaseMenuById','根据id获取菜单','菜单','POST'),(33,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/getMenuList','分页获取基础menu列表','菜单','POST'),(34,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/getBaseMenuTree','获取用户动态路由','菜单','POST'),(35,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/getMenuAuthority','获取指定角色menu','菜单','POST'),(36,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/menu/addMenuAuthority','增加menu和角色关联关系','菜单','POST'),(37,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/findFile','寻找目标文件（秒传）','分片上传','GET'),(38,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/breakpointContinue','断点续传','分片上传','POST'),(39,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/breakpointContinueFinish','断点续传完成','分片上传','POST'),(40,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/removeChunk','上传完成移除文件','分片上传','POST'),(41,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/upload','文件上传示例','文件上传与下载','POST'),(42,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/deleteFile','删除文件','文件上传与下载','POST'),(43,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/editFileName','文件名或者备注编辑','文件上传与下载','POST'),(44,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/fileUploadAndDownload/getFileList','获取上传文件列表','文件上传与下载','POST'),(45,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/system/getServerInfo','获取服务器信息','系统服务','POST'),(46,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/system/getSystemConfig','获取配置文件内容','系统服务','POST'),(47,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/system/setSystemConfig','设置配置文件内容','系统服务','POST'),(48,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/customer/customer','更新客户','客户','PUT'),(49,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/customer/customer','创建客户','客户','POST'),(50,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/customer/customer','删除客户','客户','DELETE'),(51,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/customer/customer','获取单一客户','客户','GET'),(52,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/customer/customerList','获取客户列表','客户','GET'),(53,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getDB','获取所有数据库','代码生成器','GET'),(54,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getTables','获取数据库表','代码生成器','GET'),(55,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/createTemp','自动化代码','代码生成器','POST'),(56,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/preview','预览自动化代码','代码生成器','POST'),(57,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getColumn','获取所选table的所有字段','代码生成器','GET'),(58,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/createPlug','自从创建插件包','代码生成器','POST'),(59,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/createPackage','生成包(package)','包（pkg）生成器','POST'),(60,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getPackage','获取所有包(package)','包（pkg）生成器','POST'),(61,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/delPackage','删除包(package)','包（pkg）生成器','POST'),(62,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getMeta','获取meta信息','代码生成器历史','POST'),(63,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/rollback','回滚自动生成代码','代码生成器历史','POST'),(64,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/getSysHistory','查询回滚记录','代码生成器历史','POST'),(65,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/autoCode/delSysHistory','删除回滚记录','代码生成器历史','POST'),(66,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionaryDetail/updateSysDictionaryDetail','更新字典内容','系统字典详情','PUT'),(67,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionaryDetail/createSysDictionaryDetail','新增字典内容','系统字典详情','POST'),(68,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionaryDetail/deleteSysDictionaryDetail','删除字典内容','系统字典详情','DELETE'),(69,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionaryDetail/findSysDictionaryDetail','根据ID获取字典内容','系统字典详情','GET'),(70,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionaryDetail/getSysDictionaryDetailList','获取字典内容列表','系统字典详情','GET'),(71,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionary/createSysDictionary','新增字典','系统字典','POST'),(72,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionary/deleteSysDictionary','删除字典','系统字典','DELETE'),(73,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionary/updateSysDictionary','更新字典','系统字典','PUT'),(74,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionary/findSysDictionary','根据ID获取字典','系统字典','GET'),(75,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysDictionary/getSysDictionaryList','获取字典列表','系统字典','GET'),(76,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysOperationRecord/createSysOperationRecord','新增操作记录','操作记录','POST'),(77,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysOperationRecord/findSysOperationRecord','根据ID获取操作记录','操作记录','GET'),(78,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysOperationRecord/getSysOperationRecordList','获取操作记录列表','操作记录','GET'),(79,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysOperationRecord/deleteSysOperationRecord','删除操作记录','操作记录','DELETE'),(80,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/sysOperationRecord/deleteSysOperationRecordByIds','批量删除操作历史','操作记录','DELETE'),(81,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/simpleUploader/upload','插件版分片上传','断点续传(插件版)','POST'),(82,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/simpleUploader/checkFileMd5','文件完整度验证','断点续传(插件版)','GET'),(83,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/simpleUploader/mergeFileMd5','上传完成合并文件','断点续传(插件版)','GET'),(84,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/email/emailTest','发送测试邮件','email','POST'),(85,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/email/emailSend','发送邮件示例','email','POST'),(86,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/excel/importExcel','导入excel','excel','POST'),(87,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/excel/loadExcel','下载excel','excel','GET'),(88,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/excel/exportExcel','导出excel','excel','POST'),(89,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/excel/downloadTemplate','下载excel模板','excel','GET'),(90,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authorityBtn/setAuthorityBtn','设置按钮权限','按钮权限','POST'),(91,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authorityBtn/getAuthorityBtn','获取已有按钮权限','按钮权限','POST'),(92,'2022-07-08 06:38:24.151','2022-07-08 06:38:24.151',NULL,'/authorityBtn/canRemoveAuthorityBtn','删除按钮','按钮权限','POST');
/*!40000 ALTER TABLE `sys_apis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_authorities`
--

DROP TABLE IF EXISTS `sys_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_authorities` (
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `authority_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `authority_name` varchar(191) DEFAULT NULL COMMENT '角色名',
  `parent_id` bigint unsigned DEFAULT NULL COMMENT '父角色ID',
  `default_router` varchar(191) DEFAULT 'dashboard' COMMENT '默认菜单',
  PRIMARY KEY (`authority_id`),
  UNIQUE KEY `authority_id` (`authority_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9529 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_authorities`
--

LOCK TABLES `sys_authorities` WRITE;
/*!40000 ALTER TABLE `sys_authorities` DISABLE KEYS */;
INSERT INTO `sys_authorities` VALUES ('2022-07-08 06:38:24.215','2022-07-08 06:38:24.867',NULL,888,'普通用户',0,'dashboard'),('2022-07-08 06:38:24.215','2022-07-08 06:38:24.934',NULL,8881,'普通用户子角色',888,'dashboard'),('2022-07-08 06:38:24.215','2022-07-08 06:38:24.883',NULL,9528,'测试角色',0,'dashboard');
/*!40000 ALTER TABLE `sys_authorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_authority_btns`
--

DROP TABLE IF EXISTS `sys_authority_btns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_authority_btns` (
  `authority_id` bigint unsigned DEFAULT NULL COMMENT '角色ID',
  `sys_menu_id` bigint unsigned DEFAULT NULL COMMENT '菜单ID',
  `sys_base_menu_btn_id` bigint unsigned DEFAULT NULL COMMENT '菜单按钮ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_authority_btns`
--

LOCK TABLES `sys_authority_btns` WRITE;
/*!40000 ALTER TABLE `sys_authority_btns` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_authority_btns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_authority_menus`
--

DROP TABLE IF EXISTS `sys_authority_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_authority_menus` (
  `sys_base_menu_id` bigint unsigned NOT NULL,
  `sys_authority_authority_id` bigint unsigned NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`sys_base_menu_id`,`sys_authority_authority_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_authority_menus`
--

LOCK TABLES `sys_authority_menus` WRITE;
/*!40000 ALTER TABLE `sys_authority_menus` DISABLE KEYS */;
INSERT INTO `sys_authority_menus` VALUES (1,888),(1,8881),(1,9528),(3,888),(4,888),(4,8881),(5,888),(5,8881),(6,888),(6,8881),(7,888),(7,8881),(8,888),(8,8881),(8,9528),(9,888),(9,8881),(10,888),(10,8881),(11,888),(11,8881),(12,888),(12,8881),(13,888),(14,888),(14,8881),(15,888),(15,8881),(16,888),(16,8881),(17,888),(17,8881),(18,888),(19,888),(20,888),(23,888),(24,888),(25,888),(26,888),(27,888),(28,888),(29,888),(30,888);
/*!40000 ALTER TABLE `sys_authority_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_auto_code_histories`
--

DROP TABLE IF EXISTS `sys_auto_code_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_auto_code_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `package` varchar(191) DEFAULT NULL,
  `table_name` varchar(191) DEFAULT NULL,
  `request_meta` text,
  `auto_code_path` text,
  `injection_meta` text,
  `struct_name` varchar(191) DEFAULT NULL,
  `struct_cn_name` varchar(191) DEFAULT NULL,
  `api_ids` varchar(191) DEFAULT NULL,
  `flag` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sys_auto_code_histories_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_auto_code_histories`
--

LOCK TABLES `sys_auto_code_histories` WRITE;
/*!40000 ALTER TABLE `sys_auto_code_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_auto_code_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_auto_codes`
--

DROP TABLE IF EXISTS `sys_auto_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_auto_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `package_name` varchar(191) DEFAULT NULL COMMENT '包名',
  `label` varchar(191) DEFAULT NULL COMMENT '展示名',
  `desc` varchar(191) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `idx_sys_auto_codes_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_auto_codes`
--

LOCK TABLES `sys_auto_codes` WRITE;
/*!40000 ALTER TABLE `sys_auto_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_auto_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_base_menu_btns`
--

DROP TABLE IF EXISTS `sys_base_menu_btns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_base_menu_btns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL COMMENT '按钮关键key',
  `desc` varchar(191) DEFAULT NULL,
  `sys_base_menu_id` bigint unsigned DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`),
  KEY `idx_sys_base_menu_btns_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_base_menu_btns`
--

LOCK TABLES `sys_base_menu_btns` WRITE;
/*!40000 ALTER TABLE `sys_base_menu_btns` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_base_menu_btns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_base_menu_parameters`
--

DROP TABLE IF EXISTS `sys_base_menu_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_base_menu_parameters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `sys_base_menu_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL COMMENT '地址栏携带参数为params还是query',
  `key` varchar(191) DEFAULT NULL COMMENT '地址栏携带参数的key',
  `value` varchar(191) DEFAULT NULL COMMENT '地址栏携带参数的值',
  PRIMARY KEY (`id`),
  KEY `idx_sys_base_menu_parameters_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_base_menu_parameters`
--

LOCK TABLES `sys_base_menu_parameters` WRITE;
/*!40000 ALTER TABLE `sys_base_menu_parameters` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_base_menu_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_base_menus`
--

DROP TABLE IF EXISTS `sys_base_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_base_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `menu_level` bigint unsigned DEFAULT NULL,
  `parent_id` varchar(191) DEFAULT NULL COMMENT '父菜单ID',
  `path` varchar(191) DEFAULT NULL COMMENT '路由path',
  `name` varchar(191) DEFAULT NULL COMMENT '路由name',
  `hidden` tinyint(1) DEFAULT NULL COMMENT '是否在列表隐藏',
  `component` varchar(191) DEFAULT NULL COMMENT '对应前端文件路径',
  `sort` bigint DEFAULT NULL COMMENT '排序标记',
  `keep_alive` tinyint(1) DEFAULT NULL COMMENT '附加属性',
  `default_menu` tinyint(1) DEFAULT NULL COMMENT '附加属性',
  `title` varchar(191) DEFAULT NULL COMMENT '附加属性',
  `icon` varchar(191) DEFAULT NULL COMMENT '附加属性',
  `close_tab` tinyint(1) DEFAULT NULL COMMENT '附加属性',
  PRIMARY KEY (`id`),
  KEY `idx_sys_base_menus_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_base_menus`
--

LOCK TABLES `sys_base_menus` WRITE;
/*!40000 ALTER TABLE `sys_base_menus` DISABLE KEYS */;
INSERT INTO `sys_base_menus` VALUES (1,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','dashboard','dashboard',0,'view/dashboard/index.vue',1,0,0,'仪表盘','odometer',0),(2,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825','2022-07-08 06:39:07.260',0,'0','about','about',0,'view/about/index.vue',9,0,0,'关于我们','info-filled',0),(3,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','admin','superAdmin',0,'view/superAdmin/index.vue',3,0,0,'超级管理员','user',0),(4,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','authority','authority',0,'view/superAdmin/authority/authority.vue',1,0,0,'角色管理','avatar',0),(5,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','menu','menu',0,'view/superAdmin/menu/menu.vue',2,1,0,'菜单管理','tickets',0),(6,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','api','api',0,'view/superAdmin/api/api.vue',3,1,0,'api管理','platform',0),(7,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','user','user',0,'view/superAdmin/user/user.vue',4,0,0,'用户管理','coordinate',0),(8,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','person','person',1,'view/person/person.vue',4,0,0,'个人信息','message',0),(9,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','example','example',0,'view/example/index.vue',7,0,0,'示例文件','management',0),(10,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'9','excel','excel',0,'view/example/excel/excel.vue',4,0,0,'excel导入导出','takeaway-box',0),(11,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'9','upload','upload',0,'view/example/upload/upload.vue',5,0,0,'媒体库（上传下载）','upload',0),(12,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'9','breakpoint','breakpoint',0,'view/example/breakpoint/breakpoint.vue',6,0,0,'断点续传','upload-filled',0),(13,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'9','customer','customer',0,'view/example/customer/customer.vue',7,0,0,'客户列表（资源示例）','avatar',0),(14,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','systemTools','systemTools',0,'view/systemTools/index.vue',5,0,0,'系统工具','tools',0),(15,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','autoCode','autoCode',0,'view/systemTools/autoCode/index.vue',1,1,0,'代码生成器','cpu',0),(16,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','formCreate','formCreate',0,'view/systemTools/formCreate/index.vue',2,1,0,'表单生成器','magic-stick',0),(17,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','system','system',0,'view/systemTools/system/system.vue',3,0,0,'系统配置','operation',0),(18,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','dictionary','dictionary',0,'view/superAdmin/dictionary/sysDictionary.vue',5,0,0,'字典管理','notebook',0),(19,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','dictionaryDetail/:id','dictionaryDetail',1,'view/superAdmin/dictionary/sysDictionaryDetail.vue',1,0,0,'字典详情-${id}','order',0),(20,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'3','operation','operation',0,'view/superAdmin/operation/sysOperationRecord.vue',6,0,0,'操作历史','pie-chart',0),(21,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'9','simpleUploader','simpleUploader',0,'view/example/simpleUploader/simpleUploader',6,0,0,'断点续传（插件版）','upload',0),(22,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825','2022-07-08 06:39:40.437',0,'0','https://www.gin-vue-admin.com','https://www.gin-vue-admin.com',0,'/',0,0,0,'官方网站','home-filled',0),(23,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','state','state',0,'view/system/state.vue',8,0,0,'服务器状态','cloudy',0),(24,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','autoCodeAdmin','autoCodeAdmin',0,'view/systemTools/autoCodeAdmin/index.vue',1,0,0,'自动化代码管理','magic-stick',0),(25,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','autoCodeEdit/:id','autoCodeEdit',1,'view/systemTools/autoCode/index.vue',0,0,0,'自动化代码-${id}','magic-stick',0),(26,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'14','autoPkg','autoPkg',0,'view/systemTools/autoPkg/autoPkg.vue',0,0,0,'自动化package','folder',0),(27,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'28','autoPlug','autoPlug',0,'view/systemTools/autoPlug/autoPlug.vue',4,0,0,'自动化插件模板','folder',0),(28,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'0','plugin','plugin',0,'view/routerHolder.vue',6,0,0,'插件系统','cherry',0),(29,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'28','plugin-email','plugin-email',0,'plugin/email/view/index.vue',1,0,0,'邮件插件','message',0),(30,'2022-07-08 06:38:24.825','2022-07-08 06:38:24.825',NULL,0,'28','https://plugin.gin-vue-admin.com/','https://plugin.gin-vue-admin.com/',0,'https://plugin.gin-vue-admin.com/',0,0,0,'插件市场','shop',0);
/*!40000 ALTER TABLE `sys_base_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_data_authority_id`
--

DROP TABLE IF EXISTS `sys_data_authority_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_data_authority_id` (
  `sys_authority_authority_id` bigint unsigned NOT NULL COMMENT '角色ID',
  `data_authority_id_authority_id` bigint unsigned NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`sys_authority_authority_id`,`data_authority_id_authority_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_data_authority_id`
--

LOCK TABLES `sys_data_authority_id` WRITE;
/*!40000 ALTER TABLE `sys_data_authority_id` DISABLE KEYS */;
INSERT INTO `sys_data_authority_id` VALUES (888,888),(888,8881),(888,9528),(9528,8881),(9528,9528);
/*!40000 ALTER TABLE `sys_data_authority_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dictionaries`
--

DROP TABLE IF EXISTS `sys_dictionaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dictionaries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL COMMENT '字典名（中）',
  `type` varchar(191) DEFAULT NULL COMMENT '字典名（英）',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `desc` varchar(191) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `idx_sys_dictionaries_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dictionaries`
--

LOCK TABLES `sys_dictionaries` WRITE;
/*!40000 ALTER TABLE `sys_dictionaries` DISABLE KEYS */;
INSERT INTO `sys_dictionaries` VALUES (1,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.340',NULL,'性别','gender',1,'性别字典'),(2,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.405',NULL,'数据库int类型','int',1,'int类型对应的数据库类型'),(3,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.453',NULL,'数据库时间日期类型','time.Time',1,'数据库时间日期类型'),(4,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.503',NULL,'数据库浮点型','float64',1,'数据库浮点型'),(5,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.548',NULL,'数据库字符串','string',1,'数据库字符串'),(6,'2022-07-08 06:38:24.317','2022-07-08 06:38:24.577',NULL,'数据库bool类型','bool',1,'数据库bool类型');
/*!40000 ALTER TABLE `sys_dictionaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dictionary_details`
--

DROP TABLE IF EXISTS `sys_dictionary_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dictionary_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `label` varchar(191) DEFAULT NULL COMMENT '展示值',
  `value` bigint DEFAULT NULL COMMENT '字典值',
  `status` tinyint(1) DEFAULT NULL COMMENT '启用状态',
  `sort` bigint DEFAULT NULL COMMENT '排序标记',
  `sys_dictionary_id` bigint unsigned DEFAULT NULL COMMENT '关联标记',
  PRIMARY KEY (`id`),
  KEY `idx_sys_dictionary_details_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dictionary_details`
--

LOCK TABLES `sys_dictionary_details` WRITE;
/*!40000 ALTER TABLE `sys_dictionary_details` DISABLE KEYS */;
INSERT INTO `sys_dictionary_details` VALUES (1,'2022-07-08 06:38:24.342','2022-07-08 06:38:24.342',NULL,'男',1,1,1,1),(2,'2022-07-08 06:38:24.342','2022-07-08 06:38:24.342',NULL,'女',2,1,2,1),(3,'2022-07-08 06:38:24.409','2022-07-08 06:38:24.409',NULL,'smallint',1,1,1,2),(4,'2022-07-08 06:38:24.409','2022-07-08 06:38:24.409',NULL,'mediumint',2,1,2,2),(5,'2022-07-08 06:38:24.409','2022-07-08 06:38:24.409',NULL,'int',3,1,3,2),(6,'2022-07-08 06:38:24.409','2022-07-08 06:38:24.409',NULL,'bigint',4,1,4,2),(7,'2022-07-08 06:38:24.461','2022-07-08 06:38:24.461',NULL,'date',0,1,0,3),(8,'2022-07-08 06:38:24.461','2022-07-08 06:38:24.461',NULL,'time',1,1,1,3),(9,'2022-07-08 06:38:24.461','2022-07-08 06:38:24.461',NULL,'year',2,1,2,3),(10,'2022-07-08 06:38:24.461','2022-07-08 06:38:24.461',NULL,'datetime',3,1,3,3),(11,'2022-07-08 06:38:24.461','2022-07-08 06:38:24.461',NULL,'timestamp',5,1,5,3),(12,'2022-07-08 06:38:24.504','2022-07-08 06:38:24.504',NULL,'float',0,1,0,4),(13,'2022-07-08 06:38:24.504','2022-07-08 06:38:24.504',NULL,'double',1,1,1,4),(14,'2022-07-08 06:38:24.504','2022-07-08 06:38:24.504',NULL,'decimal',2,1,2,4),(15,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'char',0,1,0,5),(16,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'varchar',1,1,1,5),(17,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'tinyblob',2,1,2,5),(18,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'tinytext',3,1,3,5),(19,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'text',4,1,4,5),(20,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'blob',5,1,5,5),(21,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'mediumblob',6,1,6,5),(22,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'mediumtext',7,1,7,5),(23,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'longblob',8,1,8,5),(24,'2022-07-08 06:38:24.552','2022-07-08 06:38:24.552',NULL,'longtext',9,1,9,5),(25,'2022-07-08 06:38:24.580','2022-07-08 06:38:24.580',NULL,'tinyint',0,1,0,6);
/*!40000 ALTER TABLE `sys_dictionary_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_operation_records`
--

DROP TABLE IF EXISTS `sys_operation_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_operation_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `ip` varchar(191) DEFAULT NULL COMMENT '请求ip',
  `method` varchar(191) DEFAULT NULL COMMENT '请求方法',
  `path` varchar(191) DEFAULT NULL COMMENT '请求路径',
  `status` bigint DEFAULT NULL COMMENT '请求状态',
  `latency` bigint DEFAULT NULL COMMENT '延迟',
  `agent` varchar(191) DEFAULT NULL COMMENT '代理',
  `error_message` varchar(191) DEFAULT NULL COMMENT '错误信息',
  `body` text COMMENT '请求Body',
  `resp` text COMMENT '响应Body',
  `user_id` bigint unsigned DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `idx_sys_operation_records_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_operation_records`
--

LOCK TABLES `sys_operation_records` WRITE;
/*!40000 ALTER TABLE `sys_operation_records` DISABLE KEYS */;
INSERT INTO `sys_operation_records` VALUES (1,'2022-07-08 06:38:43.900','2022-07-08 06:38:43.900',NULL,'183.94.133.93','POST','/system/getServerInfo',200,207602643,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":11},\"cpu\":{\"cpus\":[14.28571428658047],\"cores\":1},\"ram\":{\"usedMb\":770,\"totalMb\":1817,\"usedPercent\":42},\"disk\":{\"usedMb\":39277,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(2,'2022-07-08 06:39:07.302','2022-07-08 06:39:07.302',NULL,'183.94.133.93','POST','/menu/deleteBaseMenu',200,46034879,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','{\"ID\":2}','{\"code\":0,\"data\":{},\"msg\":\"删除成功\"}',1),(3,'2022-07-08 06:39:14.998','2022-07-08 06:39:14.998',NULL,'183.94.133.93','POST','/system/getServerInfo',200,200736214,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":11},\"cpu\":{\"cpus\":[0],\"cores\":1},\"ram\":{\"usedMb\":777,\"totalMb\":1817,\"usedPercent\":42},\"disk\":{\"usedMb\":39277,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(4,'2022-07-08 06:39:40.483','2022-07-08 06:39:40.483',NULL,'183.94.133.93','POST','/menu/deleteBaseMenu',200,49991737,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','{\"ID\":22}','{\"code\":0,\"data\":{},\"msg\":\"删除成功\"}',1),(5,'2022-07-08 06:39:49.007','2022-07-08 06:39:49.007',NULL,'183.94.133.93','POST','/system/getServerInfo',200,200735752,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":11},\"cpu\":{\"cpus\":[10.526315789574458],\"cores\":1},\"ram\":{\"usedMb\":775,\"totalMb\":1817,\"usedPercent\":42},\"disk\":{\"usedMb\":39277,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(6,'2022-07-08 06:39:56.306','2022-07-08 06:39:56.306',NULL,'183.94.133.93','POST','/system/getSystemConfig',200,445698,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"config\":{\"jwt\":{\"signing-key\":\"dea20045-8db1-4021-b6e5-61e422455036\",\"expires-time\":604800,\"buffer-time\":86400,\"issuer\":\"qmPlus\"},\"zap\":{\"level\":\"info\",\"prefix\":\"[github.com/liujianjiang/goadmin/server]\",\"format\":\"console\",\"director\":\"log\",\"encode-level\":\"LowercaseColorLevelEncoder\",\"stacktrace-key\":\"stacktrace\",\"max-age\":30,\"show-line\":true,\"log-in-console\":true},\"redis\":{\"db\":0,\"addr\":\"177.7.0.14:6379\",\"password\":\"\"},\"email\":{\"to\":\"875394153@qq.com\",\"port\":465,\"from\":\"875394153@qq.com\",\"host\":\"smtp.qq.com\",\"is-ssl\":true,\"secret\":\"genmaouvhhbxbegf\",\"nickname\":\"刘建江\"},\"system\":{\"env\":\"public\",\"addr\":8989,\"db-type\":\"mysql\",\"oss-type\":\"local\",\"use-multipoint\":false,\"use-redis\":false,\"iplimit-count\":15000,\"iplimit-time\":3600},\"captcha\":{\"key-long\":6,\"img-width\":240,\"img-height\":80},\"autocode\":{\"transfer-restart\":true,\"root\":\"/go/src/github.com/liujianjiang/goadmin\",\"server\":\"/server\",\"server-api\":\"/api/v1/%s\",\"server-plug\":\"/plugin/%s\",\"server-initialize\":\"/initialize\",\"server-model\":\"/model/%s\",\"server-request\":\"/model/%s/request/\",\"server-router\":\"/router/%s\",\"server-service\":\"/service/%s\",\"web\":\"/web/src\",\"web-api\":\"/api\",\"web-form\":\"/view\",\"web-table\":\"/view\"},\"mysql\":{\"path\":\"81.68.202.80\",\"port\":\"3306\",\"config\":\"charset=utf8mb4\\u0026parseTime=True\\u0026loc=Local\",\"db-name\":\"goadmin\",\"username\":\"goadmin\",\"password\":\"123456\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"error\",\"log-zap\":false},\"pgsql\":{\"path\":\"\",\"port\":\"\",\"config\":\"\",\"db-name\":\"\",\"username\":\"\",\"password\":\"\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"\",\"log-zap\":false},\"db-list\":[{\"disable\":false,\"type\":\"\",\"alias-name\":\"\",\"path\":\"\",\"port\":\"\",\"config\":\"\",\"db-name\":\"\",\"username\":\"\",\"password\":\"\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"\",\"log-zap\":false}],\"local\":{\"path\":\"uploads/file\",\"store-path\":\"uploads/file\"},\"qiniu\":{\"zone\":\"ZoneHuaDong\",\"bucket\":\"\",\"img-path\":\"\",\"use-https\":false,\"access-key\":\"\",\"secret-key\":\"\",\"use-cdn-domains\":false},\"aliyun-oss\":{\"endpoint\":\"yourEndpoint\",\"access-key-id\":\"yourAccessKeyId\",\"access-key-secret\":\"yourAccessKeySecret\",\"bucket-name\":\"yourBucketName\",\"bucket-url\":\"yourBucketUrl\",\"base-path\":\"yourBasePath\"},\"hua-wei-obs\":{\"path\":\"you-path\",\"bucket\":\"you-bucket\",\"endpoint\":\"you-endpoint\",\"access-key\":\"you-access-key\",\"secret-key\":\"you-secret-key\"},\"tencent-cos\":{\"bucket\":\"xxxxx-10005608\",\"region\":\"ap-shanghai\",\"secret-id\":\"xxxxxxxx\",\"secret-key\":\"xxxxxxxx\",\"base-url\":\"https://gin.vue.admin\",\"path-prefix\":\"github.com/liujianjiang/goadmin/server\"},\"aws-s3\":{\"bucket\":\"xxxxx-10005608\",\"region\":\"ap-shanghai\",\"endpoint\":\"\",\"s3-force-path-style\":false,\"disable-ssl\":false,\"secret-id\":\"xxxxxxxx\",\"secret-key\":\"xxxxxxxx\",\"base-url\":\"https://gin.vue.admin\",\"path-prefix\":\"github.com/liujianjiang/goadmin/server\"},\"excel\":{\"dir\":\"./resource/excel/\"},\"timer\":{\"start\":true,\"spec\":\"@daily\",\"detail\":[{\"tableName\":\"sys_operation_records\",\"compareField\":\"created_at\",\"interval\":\"2160h\"},{\"tableName\":\"jwt_blacklists\",\"compareField\":\"created_at\",\"interval\":\"168h\"}]},\"cors\":{\"mode\":\"whitelist\",\"whitelist\":[{\"allow-origin\":\"example1.com\",\"allow-methods\":\"GET, POST\",\"allow-headers\":\"content-type\",\"expose-headers\":\"Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Content-Type\",\"allow-credentials\":true},{\"allow-origin\":\"example2.com\",\"allow-methods\":\"GET, POST\",\"allow-headers\":\"content-type\",\"expose-headers\":\"Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Content-Type\",\"allow-credentials\":true}]}}},\"msg\":\"获取成功\"}',1),(7,'2022-07-08 06:40:28.426','2022-07-08 06:40:28.426',NULL,'183.94.133.93','POST','/system/getServerInfo',200,200642860,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":11},\"cpu\":{\"cpus\":[10.526315789574458],\"cores\":1},\"ram\":{\"usedMb\":777,\"totalMb\":1817,\"usedPercent\":42},\"disk\":{\"usedMb\":39277,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(8,'2022-07-08 06:42:32.713','2022-07-08 06:42:32.713',NULL,'183.94.133.93','POST','/system/getSystemConfig',200,56735,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"config\":{\"jwt\":{\"signing-key\":\"dea20045-8db1-4021-b6e5-61e422455036\",\"expires-time\":604800,\"buffer-time\":86400,\"issuer\":\"qmPlus\"},\"zap\":{\"level\":\"info\",\"prefix\":\"[github.com/liujianjiang/goadmin/server]\",\"format\":\"console\",\"director\":\"log\",\"encode-level\":\"LowercaseColorLevelEncoder\",\"stacktrace-key\":\"stacktrace\",\"max-age\":30,\"show-line\":true,\"log-in-console\":true},\"redis\":{\"db\":0,\"addr\":\"177.7.0.14:6379\",\"password\":\"\"},\"email\":{\"to\":\"875394153@qq.com\",\"port\":465,\"from\":\"875394153@qq.com\",\"host\":\"smtp.qq.com\",\"is-ssl\":true,\"secret\":\"genmaouvhhbxbegf\",\"nickname\":\"刘建江\"},\"system\":{\"env\":\"public\",\"addr\":8989,\"db-type\":\"mysql\",\"oss-type\":\"local\",\"use-multipoint\":false,\"use-redis\":false,\"iplimit-count\":15000,\"iplimit-time\":3600},\"captcha\":{\"key-long\":6,\"img-width\":240,\"img-height\":80},\"autocode\":{\"transfer-restart\":true,\"root\":\"/go/src/github.com/liujianjiang/goadmin\",\"server\":\"/server\",\"server-api\":\"/api/v1/%s\",\"server-plug\":\"/plugin/%s\",\"server-initialize\":\"/initialize\",\"server-model\":\"/model/%s\",\"server-request\":\"/model/%s/request/\",\"server-router\":\"/router/%s\",\"server-service\":\"/service/%s\",\"web\":\"/web/src\",\"web-api\":\"/api\",\"web-form\":\"/view\",\"web-table\":\"/view\"},\"mysql\":{\"path\":\"81.68.202.80\",\"port\":\"3306\",\"config\":\"charset=utf8mb4\\u0026parseTime=True\\u0026loc=Local\",\"db-name\":\"goadmin\",\"username\":\"goadmin\",\"password\":\"123456\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"error\",\"log-zap\":false},\"pgsql\":{\"path\":\"\",\"port\":\"\",\"config\":\"\",\"db-name\":\"\",\"username\":\"\",\"password\":\"\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"\",\"log-zap\":false},\"db-list\":[{\"disable\":false,\"type\":\"\",\"alias-name\":\"\",\"path\":\"\",\"port\":\"\",\"config\":\"\",\"db-name\":\"\",\"username\":\"\",\"password\":\"\",\"max-idle-conns\":10,\"max-open-conns\":100,\"log-mode\":\"\",\"log-zap\":false}],\"local\":{\"path\":\"uploads/file\",\"store-path\":\"uploads/file\"},\"qiniu\":{\"zone\":\"ZoneHuaDong\",\"bucket\":\"\",\"img-path\":\"\",\"use-https\":false,\"access-key\":\"\",\"secret-key\":\"\",\"use-cdn-domains\":false},\"aliyun-oss\":{\"endpoint\":\"yourEndpoint\",\"access-key-id\":\"yourAccessKeyId\",\"access-key-secret\":\"yourAccessKeySecret\",\"bucket-name\":\"yourBucketName\",\"bucket-url\":\"yourBucketUrl\",\"base-path\":\"yourBasePath\"},\"hua-wei-obs\":{\"path\":\"you-path\",\"bucket\":\"you-bucket\",\"endpoint\":\"you-endpoint\",\"access-key\":\"you-access-key\",\"secret-key\":\"you-secret-key\"},\"tencent-cos\":{\"bucket\":\"xxxxx-10005608\",\"region\":\"ap-shanghai\",\"secret-id\":\"xxxxxxxx\",\"secret-key\":\"xxxxxxxx\",\"base-url\":\"https://gin.vue.admin\",\"path-prefix\":\"github.com/liujianjiang/goadmin/server\"},\"aws-s3\":{\"bucket\":\"xxxxx-10005608\",\"region\":\"ap-shanghai\",\"endpoint\":\"\",\"s3-force-path-style\":false,\"disable-ssl\":false,\"secret-id\":\"xxxxxxxx\",\"secret-key\":\"xxxxxxxx\",\"base-url\":\"https://gin.vue.admin\",\"path-prefix\":\"github.com/liujianjiang/goadmin/server\"},\"excel\":{\"dir\":\"./resource/excel/\"},\"timer\":{\"start\":true,\"spec\":\"@daily\",\"detail\":[{\"tableName\":\"sys_operation_records\",\"compareField\":\"created_at\",\"interval\":\"2160h\"},{\"tableName\":\"jwt_blacklists\",\"compareField\":\"created_at\",\"interval\":\"168h\"}]},\"cors\":{\"mode\":\"whitelist\",\"whitelist\":[{\"allow-origin\":\"example1.com\",\"allow-methods\":\"GET, POST\",\"allow-headers\":\"content-type\",\"expose-headers\":\"Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Content-Type\",\"allow-credentials\":true},{\"allow-origin\":\"example2.com\",\"allow-methods\":\"GET, POST\",\"allow-headers\":\"content-type\",\"expose-headers\":\"Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Content-Type\",\"allow-credentials\":true}]}}},\"msg\":\"获取成功\"}',1),(9,'2022-07-11 07:15:58.251','2022-07-11 07:15:58.251',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200704646,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[11.111111108191746],\"cores\":1},\"ram\":{\"usedMb\":576,\"totalMb\":1817,\"usedPercent\":31},\"disk\":{\"usedMb\":44499,\"usedGb\":43,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":92}}},\"msg\":\"获取成功\"}',1),(10,'2022-07-11 07:16:08.921','2022-07-11 07:16:08.921',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200857446,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[0],\"cores\":1},\"ram\":{\"usedMb\":577,\"totalMb\":1817,\"usedPercent\":31},\"disk\":{\"usedMb\":44499,\"usedGb\":43,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":92}}},\"msg\":\"获取成功\"}',1),(11,'2022-07-11 07:16:18.921','2022-07-11 07:16:18.921',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200744143,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[0],\"cores\":1},\"ram\":{\"usedMb\":579,\"totalMb\":1817,\"usedPercent\":31},\"disk\":{\"usedMb\":44499,\"usedGb\":43,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":92}}},\"msg\":\"获取成功\"}',1),(12,'2022-07-11 07:16:28.964','2022-07-11 07:16:28.964',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200690766,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[0],\"cores\":1},\"ram\":{\"usedMb\":581,\"totalMb\":1817,\"usedPercent\":31},\"disk\":{\"usedMb\":44499,\"usedGb\":43,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":92}}},\"msg\":\"获取成功\"}',1),(13,'2022-07-11 07:16:38.238','2022-07-11 07:16:38.238',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200704100,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[0],\"cores\":1},\"ram\":{\"usedMb\":583,\"totalMb\":1817,\"usedPercent\":32},\"disk\":{\"usedMb\":44499,\"usedGb\":43,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":92}}},\"msg\":\"获取成功\"}',1),(14,'2022-07-11 09:44:26.502','2022-07-11 09:44:26.502',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202048434,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":701,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37522,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":77}}},\"msg\":\"获取成功\"}',1),(15,'2022-07-11 09:44:36.503','2022-07-11 09:44:36.503',NULL,'183.94.133.186','POST','/system/getServerInfo',200,204094088,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":704,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37550,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":77}}},\"msg\":\"获取成功\"}',1),(16,'2022-07-11 09:44:46.507','2022-07-11 09:44:46.507',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202881430,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":705,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37578,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":77}}},\"msg\":\"获取成功\"}',1),(17,'2022-07-11 09:44:56.514','2022-07-11 09:44:56.514',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201003892,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37605,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(18,'2022-07-11 09:45:06.500','2022-07-11 09:45:06.500',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201048074,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":708,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37633,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(19,'2022-07-11 09:45:16.514','2022-07-11 09:45:16.514',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202349199,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37663,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(20,'2022-07-11 09:45:26.994','2022-07-11 09:45:26.994',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201317650,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":707,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37694,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(21,'2022-07-11 09:45:36.984','2022-07-11 09:45:36.984',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201658747,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":707,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37723,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(22,'2022-07-11 09:45:46.499','2022-07-11 09:45:46.499',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200586514,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":707,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37751,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(23,'2022-07-11 09:45:56.978','2022-07-11 09:45:56.978',NULL,'183.94.133.186','POST','/system/getServerInfo',200,204029776,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":707,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37783,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(24,'2022-07-11 09:46:07.006','2022-07-11 09:46:07.006',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201339124,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37813,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(25,'2022-07-11 09:46:16.982','2022-07-11 09:46:16.982',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201006932,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37843,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(26,'2022-07-11 09:46:27.003','2022-07-11 09:46:27.003',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200562436,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":707,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37873,\"usedGb\":36,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(27,'2022-07-11 09:46:36.989','2022-07-11 09:46:36.989',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202760748,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37904,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(28,'2022-07-11 09:46:46.989','2022-07-11 09:46:46.989',NULL,'183.94.133.186','POST','/system/getServerInfo',200,203086639,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":706,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37934,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(29,'2022-07-11 09:46:56.997','2022-07-11 09:46:56.997',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202324770,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":708,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":37964,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(30,'2022-07-11 09:47:07.021','2022-07-11 09:47:07.021',NULL,'183.94.133.186','POST','/system/getServerInfo',200,203090450,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":37994,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(31,'2022-07-11 09:47:16.999','2022-07-11 09:47:16.999',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202732797,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38022,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(32,'2022-07-11 09:47:26.986','2022-07-11 09:47:26.986',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202938958,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":709,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38051,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":78}}},\"msg\":\"获取成功\"}',1),(33,'2022-07-11 09:47:36.982','2022-07-11 09:47:36.982',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200908306,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38081,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(34,'2022-07-11 09:47:46.992','2022-07-11 09:47:46.992',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201936817,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38110,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(35,'2022-07-11 09:47:56.988','2022-07-11 09:47:56.988',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202895252,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38138,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(36,'2022-07-11 09:48:07.003','2022-07-11 09:48:07.003',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200947165,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38168,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(37,'2022-07-11 09:48:16.983','2022-07-11 09:48:16.983',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200865466,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":709,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38198,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(38,'2022-07-11 09:48:26.977','2022-07-11 09:48:26.977',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200810637,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38229,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(39,'2022-07-11 09:48:37.013','2022-07-11 09:48:37.013',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202956682,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38259,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(40,'2022-07-11 09:48:46.997','2022-07-11 09:48:46.997',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201114787,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38289,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(41,'2022-07-11 09:48:56.992','2022-07-11 09:48:56.992',NULL,'183.94.133.186','POST','/system/getServerInfo',200,203026891,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38319,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(42,'2022-07-11 09:49:06.990','2022-07-11 09:49:06.990',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200782803,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38348,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(43,'2022-07-11 09:49:16.988','2022-07-11 09:49:16.988',NULL,'183.94.133.186','POST','/system/getServerInfo',200,204141063,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38378,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(44,'2022-07-11 09:49:26.974','2022-07-11 09:49:26.974',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201143473,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38409,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(45,'2022-07-11 09:49:36.994','2022-07-11 09:49:36.994',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200371431,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38439,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(46,'2022-07-11 09:49:46.999','2022-07-11 09:49:46.999',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200921246,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":712,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38469,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(47,'2022-07-11 09:49:56.980','2022-07-11 09:49:56.980',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201947574,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":713,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38499,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(48,'2022-07-11 09:50:07.000','2022-07-11 09:50:07.000',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200621849,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":713,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38528,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":79}}},\"msg\":\"获取成功\"}',1),(49,'2022-07-11 09:50:16.992','2022-07-11 09:50:16.992',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201399564,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":712,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38559,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(50,'2022-07-11 09:50:26.998','2022-07-11 09:50:26.998',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201041079,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38589,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(51,'2022-07-11 09:50:36.998','2022-07-11 09:50:36.998',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202933058,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":712,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38619,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(52,'2022-07-11 09:50:46.999','2022-07-11 09:50:46.999',NULL,'183.94.133.186','POST','/system/getServerInfo',200,203240865,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":711,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38650,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(53,'2022-07-11 09:51:48.049','2022-07-11 09:51:48.049',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200882190,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":38834,\"usedGb\":37,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(54,'2022-07-11 09:52:49.096','2022-07-11 09:52:49.096',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201768769,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":710,\"totalMb\":1817,\"usedPercent\":39},\"disk\":{\"usedMb\":39006,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":80}}},\"msg\":\"获取成功\"}',1),(55,'2022-07-11 09:53:50.060','2022-07-11 09:53:50.060',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201766186,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":691,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":39179,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(56,'2022-07-11 09:54:51.056','2022-07-11 09:54:51.056',NULL,'183.94.133.186','POST','/system/getServerInfo',200,201848720,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":691,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":39351,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":81}}},\"msg\":\"获取成功\"}',1),(57,'2022-07-11 09:55:52.043','2022-07-11 09:55:52.043',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202092627,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":690,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":39519,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":82}}},\"msg\":\"获取成功\"}',1),(58,'2022-07-11 09:56:53.049','2022-07-11 09:56:53.049',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202980758,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":691,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":39699,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":82}}},\"msg\":\"获取成功\"}',1),(59,'2022-07-11 09:57:54.067','2022-07-11 09:57:54.067',NULL,'183.94.133.186','POST','/system/getServerInfo',200,200969986,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":689,\"totalMb\":1817,\"usedPercent\":37},\"disk\":{\"usedMb\":39880,\"usedGb\":38,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":82}}},\"msg\":\"获取成功\"}',1),(60,'2022-07-11 09:58:55.069','2022-07-11 09:58:55.069',NULL,'183.94.133.186','POST','/system/getServerInfo',200,205760567,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":689,\"totalMb\":1817,\"usedPercent\":37},\"disk\":{\"usedMb\":40049,\"usedGb\":39,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":83}}},\"msg\":\"获取成功\"}',1),(61,'2022-07-11 09:59:56.058','2022-07-11 09:59:56.058',NULL,'183.94.133.186','POST','/system/getServerInfo',200,202948843,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','','','{\"code\":0,\"data\":{\"server\":{\"os\":{\"goos\":\"linux\",\"numCpu\":1,\"compiler\":\"gc\",\"goVersion\":\"go1.18.3\",\"numGoroutine\":12},\"cpu\":{\"cpus\":[100],\"cores\":1},\"ram\":{\"usedMb\":691,\"totalMb\":1817,\"usedPercent\":38},\"disk\":{\"usedMb\":40224,\"usedGb\":39,\"totalMb\":50331,\"totalGb\":49,\"usedPercent\":83}}},\"msg\":\"获取成功\"}',1);
/*!40000 ALTER TABLE `sys_operation_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_authority`
--

DROP TABLE IF EXISTS `sys_user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_authority` (
  `sys_user_id` bigint unsigned NOT NULL,
  `sys_authority_authority_id` bigint unsigned NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`sys_user_id`,`sys_authority_authority_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_authority`
--

LOCK TABLES `sys_user_authority` WRITE;
/*!40000 ALTER TABLE `sys_user_authority` DISABLE KEYS */;
INSERT INTO `sys_user_authority` VALUES (1,888),(1,8881),(1,9528),(2,888);
/*!40000 ALTER TABLE `sys_user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_users`
--

DROP TABLE IF EXISTS `sys_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `uuid` varchar(191) DEFAULT NULL COMMENT '用户UUID',
  `username` varchar(191) DEFAULT NULL COMMENT '用户登录名',
  `password` varchar(191) DEFAULT NULL COMMENT '用户登录密码',
  `nick_name` varchar(191) DEFAULT '系统用户' COMMENT '用户昵称',
  `side_mode` varchar(191) DEFAULT 'dark' COMMENT '用户侧边主题',
  `header_img` varchar(191) DEFAULT 'https://qmplusimg.henrongyi.top/gva_header.jpg' COMMENT '用户头像',
  `base_color` varchar(191) DEFAULT '#fff' COMMENT '基础颜色',
  `active_color` varchar(191) DEFAULT '#1890ff' COMMENT '活跃颜色',
  `authority_id` bigint unsigned DEFAULT '888' COMMENT '用户角色ID',
  `phone` varchar(191) DEFAULT NULL COMMENT '用户手机号',
  `email` varchar(191) DEFAULT NULL COMMENT '用户邮箱',
  `enable` bigint DEFAULT '1' COMMENT '用户是否被冻结 1正常 2冻结',
  PRIMARY KEY (`id`),
  KEY `idx_sys_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_users`
--

LOCK TABLES `sys_users` WRITE;
/*!40000 ALTER TABLE `sys_users` DISABLE KEYS */;
INSERT INTO `sys_users` VALUES (1,'2022-07-08 06:38:24.765','2022-07-08 06:38:24.777',NULL,'ae247fcc-6426-4a9b-807d-411eb6584be3','admin','$2a$10$8Jv7kgbI7ak8BC9VxgmqV.nE4VlRccc4CrSexg.RHhuYjjY3Z3r3m','超级管理员','dark','https://qmplusimg.henrongyi.top/gva_header.jpg','#fff','#1890ff',888,'17611111111','333333333@qq.com',1),(2,'2022-07-08 06:38:24.765','2022-07-08 06:38:24.802',NULL,'1711f380-6a56-44b0-918c-967578bb30ac','a303176530','$2a$10$n8FO.GHHV33cQc2rC2Dvw.RWIcMta99z3t0It44L5sx4RRG1HqFF6','QMPlusUser','dark','https:///qmplusimg.henrongyi.top/1572075907logo.png','#fff','#1890ff',9528,'17611111111','333333333@qq.com',1);
/*!40000 ALTER TABLE `sys_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'goadmin'
--

--
-- Dumping routines for database 'goadmin'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-14 23:59:02
